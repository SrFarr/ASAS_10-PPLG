﻿namespace Daftar_Hadir
{
}

namespace Daftar_Hadir
{


    public partial class StudentDataSet
    {
    }
}
