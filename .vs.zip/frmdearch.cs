﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Daftar_Hadir
{

    public partial class frmdearch : Form
    {
        Koneksi konek = new Koneksi();
        public frmdearch()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void frmdearch_Load(object sender, EventArgs e)
        {
            timer1.Enabled = true;

        }

        private void BTNSearch_Click(object sender, EventArgs e)
        {
            SqlConnection conn = null;
            conn = konek.getConn();
            try
            {
              if(conn != null && conn.State == ConnectionState.Closed)
                {
             
                    DataTable dt = new DataTable("absensi");
                    string query =
                        "SELECT * FROM absensi WHERE " + 
                        "nama LIKE @nama OR " + 
                        "absen LIKE @absen OR " + 
                        "kelas LIKE @kelas OR " +
                        "keterangan LIKE @keterangan";
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(query,conn);
                    string cari = "%" + TXTBsearch.Text + "%";
                    cmd.Parameters.AddWithValue("@nama", cari);
                    cmd.Parameters.AddWithValue("@absen", cari);
                    cmd.Parameters.AddWithValue("@kelas", cari);
                    cmd.Parameters.AddWithValue("@keterangan", cari);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                    dataGridView1.DataSource = dt;
                    dataGridView1.AllowUserToAddRows = false;
                    dataGridView1.AllowUserToDeleteRows = false;
                    dataGridView1.ReadOnly = true;
                    dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                }         
            }
            catch(Exception ex)
            {
                MessageBox.Show("ERROR", "Terjadi kesalahan", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if( conn != null && conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
        }

        private void TXTBsearch_Enter(object sender, EventArgs e)
        {

        }

        private void TXTBsearch_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar == (char)13)
            {
                BTNSearch.PerformClick();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label3.Text = DateTime.Now.ToString("yyyy-MM-dd : HH-mm-ss");
        }
    }
}
